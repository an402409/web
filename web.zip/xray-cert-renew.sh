#!/bin/bash

.acme.sh/acme.sh --install-cert -d a-xx.xx.xx --ecc --fullchain-file  /etc/ssl/private/xx.xx.xx.crt --key-file  /etc/ssl/private/xx.xx.xx.key
echo "Xray Certificates Renewed"
       
chmod +r 755/etc/ssl/private/xx.xx.xx.key
echo "Read Permission Granted for Private Key"

sudo systemctl restart xray
echo "Xray Restarted"